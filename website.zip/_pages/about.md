---
layout: about
title: About
permalink: /
subtitle: ""
profile:
  align: right
  image: prof_pic.jpg
  image_circular: false
  more_info: >
    <p>C417, Francis and Rose Yuen Campus</p>
    <p>579 Guoquan Road</p>
    <p>Fudan University</p>
selected_papers: true
social: true
announcements:
  enabled: false
latest_posts:
  enabled: false
---


I was affiliated with the [Institute of Science and Technology for Brain-Inspired Intelligence](https://istbi.fudan.edu.cn/) and the [School of Data Science](https://sds.fudan.edu.cn/) at [Fudan University](https://www.fudan.edu.cn/).

My research lies at the intersection of statistics and artificial intelligence. I work on nonparametric methods, statistical machine learning, and functional data analysis. I am particularly interested in connecting noisy data with physical mechanisms governed by differential equations, including applications in computational neuroscience.

I obtained my Ph.D. in Statistics from [Texas A&M University](https://www.tamu.edu/) under the supervision of [Jianhua Huang](https://sds.cuhk.edu.cn/en/teacher/470). I then held a postdoctoral research position before joining Fudan. I received a B.S. in Mathematics and a B.A. in Economics from [Peking University](https://www.pku.edu.cn/).

**Prospective students:** if you are interested in joining my group, please [email me](mailto:zhangnanku@gmail.com) with your CV and a brief description of your research interests.
